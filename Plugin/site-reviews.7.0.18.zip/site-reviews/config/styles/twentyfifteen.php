<?php

return [
    'classes' => [
        'form' => 'comment-form',
    ],
];
