<?php

namespace GeminiLabs\SiteReviews\Modules\Html\FieldElements;

class Toggle extends Checkbox
{
}
