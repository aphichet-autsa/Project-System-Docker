<?php

namespace GeminiLabs\SiteReviews\Modules\Html\FieldElements;

class Date extends Text
{
}
