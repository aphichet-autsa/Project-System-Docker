<?php

namespace GeminiLabs\SiteReviews\Contracts;

/**
 * @property array $casts
 * @property array $concatenated
 * @property array $enum
 * @property array $guarded
 * @property array $mapped
 * @property array $sanitize
 */
interface DefaultsContract
{
}
