<?php

namespace GeminiLabs\SiteReviews\Contracts;

/**
 * @property \GeminiLabs\SiteReviews\Arguments $args
 * @property string                            $tag
 * @property mixed                             $with
 */
interface TagContract
{
}
