<?php

namespace GeminiLabs\SiteReviews\Exceptions;

class BindingResolutionException extends \Exception
{
}
