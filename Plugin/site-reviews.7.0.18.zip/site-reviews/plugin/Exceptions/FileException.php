<?php

namespace GeminiLabs\SiteReviews\Exceptions;

class FileException extends \RuntimeException
{
}
