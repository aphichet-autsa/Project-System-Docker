<?php

/**
 * Title: Hidden Blog
 * Slug: bizboost/hidden-blog
 * Categories: bizboost, page
 * Inserter: no
 */
?>


<?php esc_html_e ( 'Recent Blog', 'bizboost' ) ?>
