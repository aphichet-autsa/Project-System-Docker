<?php

/**
 * Title: Hidden Post
 * Slug: bizboost/hidden-post
 * Categories: bizboost, page
 * Inserter: no
 */
?>

<!-- wp:post-title {"textAlign":"left"} /-->

